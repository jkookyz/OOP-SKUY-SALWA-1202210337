public class Menu {

    // TODO Create Attribute of Menu; Name, Category, and Price then Create Setter

}
